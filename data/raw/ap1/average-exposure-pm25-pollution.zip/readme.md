# Average annual exposure to PM2.5 air pollution - Data package

This data package contains the data that powers the chart ["Average annual exposure to PM2.5 air pollution"](https://ourworldindata.org/grapher/average-exposure-pm25-pollution?v=1&csvType=full&useColumnShortNames=false) on the Our World in Data website. It was downloaded on July 01, 2025.

### Active Filters

A filtered subset of the full data was downloaded. The following filters were applied:

## CSV Structure

The high level structure of the CSV file is that each row is an observation for an entity (usually a country or region) and a timepoint (usually a year).

The first two columns in the CSV file are "Entity" and "Code". "Entity" is the name of the entity (e.g. "United States"). "Code" is the OWID internal entity code that we use if the entity is a country or region. For normal countries, this is the same as the [iso alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code of the entity (e.g. "USA") - for non-standard countries like historical countries these are custom codes.

The third column is either "Year" or "Day". If the data is annual, this is "Year" and contains only the year as an integer. If the column is "Day", the column contains a date string in the form "YYYY-MM-DD".

The final column is the data column, which is the time series that powers the chart. If the CSV data is downloaded using the "full data" option, then the column corresponds to the time series below. If the CSV data is downloaded using the "only selected data visible in the chart" option then the data column is transformed depending on the chart type and thus the association with the time series might not be as straightforward.

## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc.. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc..

## About the data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stich together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

## Detailed information about the data


## PM2.5 air pollution, mean annual exposure (micrograms per cubic meter)
Last updated: January 24, 2025  
Next update: January 2026  
Date range: 1990–2020  
Unit: micrograms per cubic meter  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Global Burden of Disease Study 2019, Institute for Health Metrics and Evaluation (IHME), via World Bank (2025) – processed by Our World in Data

#### Full citation
Global Burden of Disease Study 2019, Institute for Health Metrics and Evaluation (IHME), via World Bank (2025) – processed by Our World in Data. “PM2.5 air pollution, mean annual exposure (micrograms per cubic meter)” [dataset]. Global Burden of Disease Study 2019, Institute for Health Metrics and Evaluation (IHME), via World Bank, “World Development Indicators” [original data].
Source: Global Burden of Disease Study 2019, Institute for Health Metrics and Evaluation (IHME), via World Bank (2025) – processed by Our World In Data

### How is this data described by its producer - Global Burden of Disease Study 2019, Institute for Health Metrics and Evaluation (IHME), via World Bank (2025)?
Population-weighted exposure to ambient PM2.5 pollution is defined as the average level of exposure of a nation's population to concentrations of suspended particles measuring less than 2.5 microns in aerodynamic diameter, which are capable of penetrating deep into the respiratory tract and causing severe health damage. Exposure is calculated by weighting mean annual concentrations of PM2.5 by population in both urban and rural areas.

Limitations and exceptions: Pollutant concentrations are sensitive to local conditions, and even monitoring sites in the same city may register different levels. Direct monitoring of PM2.5 is still rare in most parts of the world, and measurement protocols and standards are not the same for all countries. These data should be considered only a general indication of air quality, intended to inform cross-country comparisons of the health risks due to particulate matter pollution. The guideline set by the World Health Organization (WHO) for PM2.5 is that annual mean concentrations should not exceed 10 micrograms per cubic meter, representing the lower range over which adverse health effects have been observed. The WHO has also recommended guideline values for emissions of PM2.5 from burning fuels in households.

Statistical concept and methodology: A. van Donkelaar, R.V. Martin, M. Brauer, N.C. Hsu, R.A. Kahn, R.C. Levy, A. Lyapustin, A.M. Sayer, D.M. Winker, "Global Estimates of Fine Particulate Matter using a Combined Geophysical-Statistical Method with Information from Satellites, Models, and Monitors," Environ. Sci. Technol 50, no. 7 (2016): 3762–3772; GBD 2017 Risk Factors Collaborators, "Global, regional, and national comparative risk assessment of 84 behavioural, environmental and occupational, and metabolic risks or clusters of risks for 194 countries and territories, 1990–2017: a systematic analysis for the Global Burden of Disease Study 2017," Lancet 392 (2018): 1923-1994; Shaddick G, Thomas M, Amini H, Broday DM, Cohen A, Frostad J, Green A, Gumy S, Liu Y, Martin RV, Prüss-Üstün A, Simpson D, van Donkelaar A, Brauer M. Data integration for the assessment of population exposure to ambient air pollution for global burden of disease assessment. Environ Sci Technol. 2018 Jun 29. Data provided by Institute for Health Metrics and Evaluation, University of Washington, Seattle. Data on exposure to ambient air pollution are derived from estimates of annual concentrations of very fine particulates produced by the Global Burden of Disease study, an international scientific effort led by the Institute for Health Metrics and Evaluation at the University of Washington. Estimates of annual concentrations are generated by combining data from atmospheric chemistry transport models, satellite observations of aerosols in the atmosphere, and ground-level monitoring of particulates. Exposure to concentrations of PM2.5 in both urban and rural areas is weighted by population and is aggregated at the national level.

### Source

#### Global Burden of Disease Study 2019, Institute for Health Metrics and Evaluation (IHME), via World Bank – World Development Indicators
Retrieved on: 2025-01-24  
Retrieved from: https://data.worldbank.org/indicator/EN.ATM.PM25.MC.M3  


    
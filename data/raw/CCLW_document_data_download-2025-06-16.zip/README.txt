Thank you for downloading the full document dataset from Climate Policy Radar and Climate Change Laws of the World!

For more information including our data dictionary, methodology and information about how to cite us, visit 
https://climatepolicyradar.notion.site/Readme-for-document-data-download-f2d55b7e238941b59559b9b1c4cc52c5

View our terms of use at https://app.climatepolicyradar.org/terms-of-use

Date data last updated: 2025-06-16